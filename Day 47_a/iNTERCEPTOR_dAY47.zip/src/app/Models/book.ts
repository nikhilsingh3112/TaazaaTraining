export interface book
{
   bookid:Number;
   title:string,
   author:string,
   description:string,
   publisher:string ;
}