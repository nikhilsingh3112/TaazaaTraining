import { Component } from '@angular/core';
import { HomeComponent } from './service/home/home.component';





@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MergeMap';
  constructor()
  {
    
  }
}
